const page = window.location.href;

const button = document.getElementById('nexus');

const div = document.createElement('div');

div.innerHTML = '<button id="nexus">Free PANDA\'s</button>';

// make div a child of the body absolute bottom right and z-index 9999

document.body.appendChild(div);

div.style.position = 'fixed';

div.style.height = '50px';

div.style.width = '100px';

div.style.bottom = '10px';

div.style.right = '10px';

console.log(div);

div.addEventListener('click', () => {
    window.open(page, '_blank');
});